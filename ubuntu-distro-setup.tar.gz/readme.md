# Ubuntu Distro Setup

A basic setup for any desktop ubuntu based linux distribution.

Simply download and extract the zip, then inside the folder, run the "run.sh" file in the terminal.

This mainly runs the basic command setup that you may often find reccomended on YouTube. It also includes some performance improvements, and also sets up clamAV to run a malware scan on any file when downloaded to your home directory. ClamAV will also have a daily cron job to scan the entire root directory at night. In adition to performance upgraded, there are also improvements to startup performance by disabling useless things such as dial up internet.

This module will also optionally install WINE and ICE (from peppermintOS)
